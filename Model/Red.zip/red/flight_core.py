"""
flight_core.py
Core (non-GUI) logic for the Flight Aerodynamic Coefficient Predictor.
Everything here is plain Python / pandas / numpy / sklearn / xgboost / lightgbm
so it can be unit-tested without a display.
"""

import os
import time
import math
import json
import traceback
import threading

import numpy as np
import pandas as pd
import joblib

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.figure import Figure

# matplotlib's Agg backend has shared global state (notably its font cache /
# text-rendering machinery) that is NOT safe for true concurrent rendering
# across threads, even when each thread uses its own separate Figure object.
# This app renders in two places that can genuinely run concurrently: a
# background training/prediction worker thread (via the plot_* functions
# below) and the main thread embedding a live figure in the GUI
# (FigureCanvasTkAgg.draw() in flight_app.py's PlotViewer). Without this
# lock, that combination can intermittently hang. Both sides serialize
# through this same lock.
MPL_LOCK = threading.Lock()

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OrdinalEncoder, StandardScaler, MinMaxScaler, RobustScaler, MaxAbsScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, explained_variance_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR

from xgboost import XGBRegressor

try:
    from lightgbm import LGBMRegressor
    HAS_LGB = True
except ImportError:
    HAS_LGB = False

ACCENT_COLOR = "#1f6feb"

try:
    import tensorflow as tf
    from tensorflow import keras
    from tensorflow.keras import layers
    HAS_TF = True
except ImportError:
    HAS_TF = False


# ======================================================================
# Hyperparameter specs (used to auto-build GUI panels AND to validate /
# clean the values that get passed to each estimator).
# Each entry: (key, kind, default, choices)
#   kind: 'int' | 'float' | 'choice' | 'bool' | 'str'
#   choices: only used for 'choice'
# A numeric default of 0 for a parameter that is normally "None" in
# sklearn (max_depth, max_leaf_nodes, max_samples, max_leaves) is treated
# as None when cleaned.
# ======================================================================

XGB_PARAM_SPECS = [
    ("n_estimators", "int", 300, None),
    ("learning_rate", "float", 0.05, None),
    ("max_depth", "int", 6, None),
    ("min_child_weight", "float", 1.0, None),
    ("subsample", "float", 1.0, None),
    ("colsample_bytree", "float", 1.0, None),
    ("colsample_bylevel", "float", 1.0, None),
    ("colsample_bynode", "float", 1.0, None),
    ("gamma", "float", 0.0, None),
    ("reg_alpha", "float", 0.0, None),
    ("reg_lambda", "float", 1.0, None),
    ("max_delta_step", "float", 0.0, None),
    ("booster", "choice", "gbtree", ["gbtree", "gblinear", "dart"]),
    ("tree_method", "choice", "hist", ["auto", "exact", "approx", "hist"]),
    ("grow_policy", "choice", "depthwise", ["depthwise", "lossguide"]),
    ("max_leaves", "int", 0, None),          # 0 -> unlimited (xgb default)
    ("max_bin", "int", 256, None),
    ("num_parallel_tree", "int", 1, None),
    ("early_stopping_rounds", "int", 50, None),
    ("random_state", "int", 42, None),
]

RF_PARAM_SPECS = [
    ("n_estimators", "int", 300, None),
    ("criterion", "choice", "squared_error",
     ["squared_error", "absolute_error", "friedman_mse", "poisson"]),
    ("max_depth", "int", 0, None),           # 0 -> None
    ("min_samples_split", "int", 2, None),
    ("min_samples_leaf", "int", 1, None),
    ("min_weight_fraction_leaf", "float", 0.0, None),
    ("max_features", "choice", "1.0", ["1.0", "sqrt", "log2"]),
    ("max_leaf_nodes", "int", 0, None),      # 0 -> None
    ("min_impurity_decrease", "float", 0.0, None),
    ("bootstrap", "bool", True, None),
    ("oob_score", "bool", False, None),
    ("n_jobs", "int", -1, None),
    ("random_state", "int", 42, None),
    ("ccp_alpha", "float", 0.0, None),
    ("max_samples", "float", 0.0, None),     # 0 -> None (only used if bootstrap)
]

SVR_PARAM_SPECS = [
    ("kernel", "choice", "rbf", ["linear", "poly", "rbf", "sigmoid"]),
    ("degree", "int", 3, None),
    ("gamma", "choice", "scale", ["scale", "auto"]),
    ("coef0", "float", 0.0, None),
    ("tol", "float", 1e-3, None),
    ("C", "float", 1.0, None),
    ("epsilon", "float", 0.1, None),
    ("shrinking", "bool", True, None),
    ("cache_size", "float", 200.0, None),
    ("max_iter", "int", -1, None),
]

LGB_PARAM_SPECS = [
    ("n_estimators", "int", 300, None),
    ("learning_rate", "float", 0.05, None),
    ("num_leaves", "int", 31, None),
    ("max_depth", "int", -1, None),
    ("min_child_samples", "int", 20, None),
    ("subsample", "float", 1.0, None),
    ("subsample_freq", "int", 0, None),
    ("colsample_bytree", "float", 1.0, None),
    ("reg_alpha", "float", 0.0, None),
    ("reg_lambda", "float", 0.0, None),
    ("min_split_gain", "float", 0.0, None),
    ("boosting_type", "choice", "gbdt", ["gbdt", "dart", "goss"]),
    ("max_bin", "int", 255, None),
    ("min_child_weight", "float", 1e-3, None),
    ("random_state", "int", 42, None),
    ("n_jobs", "int", -1, None),
]

DNN_PARAM_SPECS = [
    ("hidden_layers", "str", "128,64,32", None),   # comma separated widths
    ("activation", "choice", "relu", ["relu", "tanh", "sigmoid", "elu", "selu"]),
    ("dropout_rate", "float", 0.1, None),
    ("learning_rate", "float", 0.001, None),
    ("optimizer", "choice", "adam", ["adam", "sgd", "rmsprop"]),
    ("batch_size", "int", 32, None),
    ("epochs", "int", 200, None),
    ("early_stopping_patience", "int", 20, None),
    ("validation_split", "float", 0.15, None),
    ("loss", "choice", "mse", ["mse", "mae", "huber"]),
    ("l2_reg", "float", 0.0, None),
]

MODEL_SPECS = {
    "XGBoost": XGB_PARAM_SPECS,
    "RandomForest": RF_PARAM_SPECS,
    "SVR": SVR_PARAM_SPECS,
    "LightGBM": LGB_PARAM_SPECS,
    "DNN": DNN_PARAM_SPECS,
}

# Which algorithms have real library defaults, so unchecked params can simply
# be omitted (letting the estimator use its own default). DNN has no such
# concept — every field defines the network, so all fields are always used.
MODEL_SUPPORTS_OPTIONAL_PARAMS = {
    "XGBoost": True,
    "RandomForest": True,
    "SVR": True,
    "LightGBM": True,
    "DNN": False,
}

# One-line, plain-English explanation for every hyperparameter across all
# five models. Shown as a tooltip in the GUI. Keys match the spec 'key'
# field; a handful of names repeat across algorithms and share one entry.
PARAM_HELP = {
    "n_estimators": "Number of trees / boosting rounds to build. More can improve accuracy but takes longer and can overfit.",
    "learning_rate": "How much each new tree corrects the previous ones. Lower = more accurate but needs more trees; higher = faster but riskier.",
    "max_depth": "Maximum depth of each tree. Deeper trees fit more detail but overfit more easily. Leave at library default if unsure.",
    "min_child_weight": "Minimum sum of sample weights needed in a leaf before it can split further (XGBoost). Higher values make the model more conservative.",
    "subsample": "Fraction of training rows randomly used to grow each tree. Below 1.0 adds randomness and helps prevent overfitting.",
    "colsample_bytree": "Fraction of input features randomly sampled when building each tree.",
    "colsample_bylevel": "Fraction of input features randomly sampled at each tree depth level.",
    "colsample_bynode": "Fraction of input features randomly sampled at each individual split.",
    "gamma": "Minimum loss reduction required to make another split (XGBoost). Higher values = more conservative, fewer splits.",
    "reg_alpha": "L1 regularization strength on leaf weights. Higher values push more weights toward exactly zero (feature selection effect).",
    "reg_lambda": "L2 regularization strength on leaf weights. Higher values shrink weights and reduce overfitting.",
    "max_delta_step": "Caps how much a single tree's prediction can change in one step (XGBoost). Rarely needed; helps with imbalanced/extreme targets.",
    "booster": "Which base learner XGBoost uses: 'gbtree' (trees, most common), 'gblinear' (linear model), or 'dart' (trees with dropout).",
    "tree_method": "Algorithm XGBoost uses to build trees. 'hist' is fast and usually the best default for tabular data.",
    "grow_policy": "How XGBoost chooses which node to split next: 'depthwise' (level by level) or 'lossguide' (biggest loss-reduction first).",
    "max_leaves": "Maximum number of leaf nodes per tree (0 = unlimited / library default). Only used with grow_policy='lossguide'.",
    "max_bin": "Number of bins used to discretize continuous features for faster histogram-based splitting.",
    "num_parallel_tree": "Number of trees built in parallel per boosting round (used for tree-based random forests within XGBoost). Leave at 1 for normal boosting.",
    "early_stopping_rounds": "Stops training if the validation score hasn't improved for this many rounds. Prevents wasted training / overfitting.",
    "random_state": "Seed for randomness so results are reproducible. Any fixed number works; changing it gives a different random split of data.",
    "criterion": "The function used to measure split quality in a Random Forest (e.g. squared error, absolute error).",
    "min_samples_split": "Minimum number of samples a node must have before it's allowed to split further.",
    "min_samples_leaf": "Minimum number of samples that must end up in each leaf node. Higher values smooth the model and reduce overfitting.",
    "min_weight_fraction_leaf": "Minimum weighted fraction of the total samples required to be at a leaf node.",
    "max_features": "Number/fraction of features considered when looking for the best split at each node ('1.0' = all features, 'sqrt', or 'log2').",
    "max_leaf_nodes": "Maximum number of leaf nodes per tree (0 = unlimited / library default).",
    "min_impurity_decrease": "A split only happens if it decreases impurity by at least this amount.",
    "bootstrap": "Whether each tree is trained on a random bootstrap sample of the data (standard Random Forest behavior) or the whole dataset.",
    "oob_score": "Whether to estimate accuracy using the 'out-of-bag' samples not used to train each tree (a free validation estimate).",
    "n_jobs": "Number of CPU cores to use (-1 = use all available cores).",
    "ccp_alpha": "Cost-complexity pruning parameter. Higher values prune more of the tree away after it's built, producing a simpler model.",
    "max_samples": "Fraction of training rows drawn to build each tree, only used when bootstrap is enabled (0 = use all rows).",
    "kernel": "The function SVR uses to map inputs into a higher-dimensional space: linear, polynomial, RBF (most common), or sigmoid.",
    "degree": "Degree of the polynomial kernel (only used when kernel='poly').",
    "gamma": "How far the influence of a single training point reaches (SVR/RBF kernels). Higher = more localized, tighter fit; can overfit.",
    "coef0": "Independent term in the polynomial and sigmoid kernels. Controls how much high-degree terms influence the model.",
    "tol": "Tolerance for the optimizer's stopping criterion. Smaller values train longer for a more precise fit.",
    "C": "Regularization strength (SVR). Lower values allow a wider margin/more error; higher values fit the training data more tightly.",
    "epsilon": "Width of the 'no-penalty' zone around each prediction in SVR. Points within this margin of the true value aren't penalized.",
    "shrinking": "Whether to use the shrinking heuristic to speed up SVR training. Rarely affects results, mainly affects speed.",
    "cache_size": "Size (MB) of the kernel cache used during SVR training. Larger can speed up training on bigger datasets.",
    "max_iter": "Maximum number of optimizer iterations (-1 = no limit).",
    "num_leaves": "Maximum number of leaves per tree in LightGBM. The main way to control model complexity — larger values fit more detail.",
    "min_child_samples": "Minimum number of samples required in a leaf (LightGBM). Higher values reduce overfitting.",
    "subsample_freq": "How often (every N rounds) LightGBM performs subsampling. 0 disables subsampling even if 'subsample' is set below 1.0.",
    "min_split_gain": "Minimum loss reduction required to make another split (LightGBM).",
    "boosting_type": "LightGBM's boosting algorithm: 'gbdt' (standard, most common), 'dart' (adds dropout), or 'goss' (gradient-based sampling, faster).",
    "hidden_layers": "Sizes of each hidden layer in the neural network, comma-separated, e.g. '128,64,32' builds three layers of those widths.",
    "activation": "Activation function applied after each hidden layer. 'relu' is a strong general-purpose default.",
    "dropout_rate": "Fraction of neurons randomly disabled during each training step, to reduce overfitting. 0 disables dropout.",
    "optimizer": "Algorithm used to update the network's weights during training. 'adam' is a strong general-purpose default.",
    "batch_size": "Number of training rows processed before each weight update. Smaller = noisier but sometimes better generalization.",
    "epochs": "Maximum number of full passes over the training data.",
    "early_stopping_patience": "Stops training if validation loss hasn't improved for this many epochs in a row, and restores the best weights seen.",
    "validation_split": "Fraction of the training data held back (not trained on) each epoch, used to monitor overfitting during training.",
    "loss": "The error function the network minimizes during training: mean squared error, mean absolute error, or Huber (a mix of both, robust to outliers).",
    "l2_reg": "L2 weight-decay regularization strength applied to every hidden layer. 0 disables it.",
}


# ======================================================================
# Excel loading — supports "single sheet" (inputs+outputs together) and
# "dual sheet" (inputs on one sheet, outputs on another) layouts.
# ======================================================================

def list_sheet_names(path):
    xls = pd.ExcelFile(path)
    return xls.sheet_names


def read_sheet_columns(path, sheet_name):
    df = pd.read_excel(path, sheet_name=sheet_name, nrows=0)
    return df.columns.tolist()


def load_dataset(path, mode, input_cols, output_cols,
                  single_sheet=None, input_sheet=None, output_sheet=None):
    """
    mode: 'single' or 'dual'
    Returns (X_df, y_df)
    """
    if mode == "single":
        df = pd.read_excel(path, sheet_name=single_sheet)
        missing_in = [c for c in input_cols if c not in df.columns]
        missing_out = [c for c in output_cols if c not in df.columns]
        if missing_in:
            raise ValueError(f"Input columns not found in sheet '{single_sheet}': {missing_in}")
        if missing_out:
            raise ValueError(f"Output columns not found in sheet '{single_sheet}': {missing_out}")
        return df[input_cols].copy(), df[output_cols].copy()
    elif mode == "dual":
        df_in = pd.read_excel(path, sheet_name=input_sheet)
        df_out = pd.read_excel(path, sheet_name=output_sheet)
        missing_in = [c for c in input_cols if c not in df_in.columns]
        missing_out = [c for c in output_cols if c not in df_out.columns]
        if missing_in:
            raise ValueError(f"Input columns not found in sheet '{input_sheet}': {missing_in}")
        if missing_out:
            raise ValueError(f"Output columns not found in sheet '{output_sheet}': {missing_out}")
        return df_in[input_cols].copy(), df_out[output_cols].copy()
    else:
        raise ValueError(f"Unknown mode: {mode}")


def get_mach_range(df):
    """Returns (min, max) for a MACH-like column if present, else None."""
    for cand in df.columns:
        if cand.strip().upper() == "MACH":
            vals = pd.to_numeric(df[cand], errors="coerce").dropna()
            if len(vals):
                return float(vals.min()), float(vals.max())
    return None


# ======================================================================
# Encoding / preprocessing (shared by all tree/SVR/DNN models)
# ======================================================================

def fit_encoder(df, log_fn=print):
    df = df.copy()
    cat_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()
    if not cat_cols:
        return None, cat_cols
    for col in cat_cols:
        df[col] = df[col].astype(str).str.strip().str.lower()
    encoder = OrdinalEncoder(handle_unknown="use_encoded_value",
                              unknown_value=-1, encoded_missing_value=-2)
    encoder.fit(df[cat_cols])
    log_fn(f"[INFO] Encoder fitted | categorical cols ({len(cat_cols)}): {cat_cols}")
    return encoder, cat_cols


def encode_cat(df, encoder, cat_cols):
    df = df.copy()
    if not cat_cols:
        return df
    for col in cat_cols:
        df[col] = df[col].astype(str).str.strip().str.lower()
    df[cat_cols] = encoder.transform(df[cat_cols])
    return df


def preprocess_inputs(df, encoder, cat_cols, log_fn=print):
    df_enc = encode_cat(df.copy(), encoder, cat_cols)
    df_enc = df_enc.apply(pd.to_numeric, errors="coerce")
    nan_counts = df_enc.isna().sum()
    if nan_counts.any():
        log_fn("[WARN] NaN values after encoding (filled with 0):")
        log_fn(nan_counts[nan_counts > 0].to_string())
    df_enc = df_enc.fillna(0)
    return df_enc.to_numpy()


# ======================================================================
# Metrics
# ======================================================================

def calculate_percentage_error(actual, predicted):
    actual = np.array(actual, dtype=float)
    predicted = np.array(predicted, dtype=float)
    denom = np.where(np.abs(actual) < 1e-10, 1e-10, np.abs(actual))
    return ((predicted - actual) / denom) * 100.0


def calculate_maape(actual, predicted):
    """Mean Arctangent Absolute Percentage Error. Returns radians array (0..pi/2)."""
    actual = np.array(actual, dtype=float)
    predicted = np.array(predicted, dtype=float)
    denom = np.where(np.abs(actual) < 1e-10, 1e-10, np.abs(actual))
    ratio = np.abs((actual - predicted) / denom)
    return np.arctan(ratio)


def adjusted_r2(r2, n_samples, n_features):
    denom = max(n_samples - n_features - 1, 1)
    return 1.0 - (1.0 - r2) * (n_samples - 1) / denom


def compute_metrics_summary(y_true_df, y_pred_arr, n_features):
    """Per-coefficient R2, Explained Variance, RMSE, MAE, Adjusted R2, mean
    %error, mean|%error|, % within 5%, % within 10%, MAAPE(rad), MAAPE(%)."""
    rows = []
    for i, col in enumerate(y_true_df.columns):
        actual = y_true_df.iloc[:, i].values.astype(float)
        pred = np.asarray(y_pred_arr)[:, i].astype(float)
        n = len(actual)
        r2 = r2_score(actual, pred)
        exp_var = explained_variance_score(actual, pred)
        rmse = math.sqrt(mean_squared_error(actual, pred))
        mae = mean_absolute_error(actual, pred)
        adj_r2 = adjusted_r2(r2, n, n_features)
        pct_err = calculate_percentage_error(actual, pred)
        maape_rad = calculate_maape(actual, pred)
        rows.append({
            "coefficient": col,
            "R2": round(r2, 5),
            "Explained_Variance": round(exp_var, 5),
            "Adjusted_R2": round(adj_r2, 5),
            "RMSE": round(rmse, 6),
            "MAE": round(mae, 6),
            "Mean_%Error": round(float(np.mean(pct_err)), 3),
            "Mean_Abs_%Error": round(float(np.mean(np.abs(pct_err))), 3),
            "Pct_Within_5pct": round(float(np.mean(np.abs(pct_err) < 5.0) * 100), 2),
            "Pct_Within_10pct": round(float(np.mean(np.abs(pct_err) < 10.0) * 100), 2),
            "MAAPE_rad": round(float(np.mean(maape_rad)), 5),
            "MAAPE_pct": round(float(np.mean(maape_rad)) / (math.pi / 2) * 100, 3),
        })
    return pd.DataFrame(rows)


# ======================================================================
# Parameter cleaning (spec value -> kwarg ready for the estimator)
# ======================================================================

def clean_params(raw_values, specs, none_zero_keys=()):
    """raw_values: dict[key] -> value already cast to correct python type.
    none_zero_keys: keys where 0 means 'use library default / None'."""
    out = {}
    for key, kind, default, choices in specs:
        if key not in raw_values:
            continue
        val = raw_values[key]
        if key in none_zero_keys and val in (0, 0.0):
            continue  # let estimator use its own default
        if key == "max_features" and val == "1.0":
            val = 1.0
        out[key] = val
    return out


# ======================================================================
# Generic per-output training loop (used by XGB / RF / SVR / LightGBM)
# ======================================================================

def train_per_output(factory_fn, X_train, y_train, X_test, y_test,
                      supports_eval_set, log_fn, stop_flag=None):
    models = []
    for i, col in enumerate(y_train.columns):
        if stop_flag is not None and stop_flag.is_set():
            log_fn("[INFO] Training cancelled.")
            return None
        t0 = time.time()
        est = factory_fn()
        y_tr_col = y_train.iloc[:, i]
        y_te_col = y_test.iloc[:, i]
        if supports_eval_set:
            est.fit(X_train, y_tr_col, eval_set=[(X_test, y_te_col)], verbose=False)
        else:
            est.fit(X_train, y_tr_col)
        dt = time.time() - t0
        models.append(est)
        log_fn(f"  [{col}] trained in {dt:.2f}s")
    return models


def make_xgb_factory(params, log_fn):
    cleaned = clean_params(params, XGB_PARAM_SPECS, none_zero_keys=("max_leaves",))
    esr = cleaned.pop("early_stopping_rounds", 50)

    def factory():
        return XGBRegressor(
            objective="reg:squarederror",
            eval_metric="rmse",
            early_stopping_rounds=esr if esr and esr > 0 else None,
            verbosity=0,
            **cleaned,
        )
    return factory


def make_rf_factory(params, log_fn):
    cleaned = clean_params(params, RF_PARAM_SPECS,
                            none_zero_keys=("max_depth", "max_leaf_nodes", "max_samples"))

    def factory():
        return RandomForestRegressor(**cleaned)
    return factory


def make_svr_factory(params, log_fn):
    cleaned = clean_params(params, SVR_PARAM_SPECS)

    def factory():
        return SVR(**cleaned)
    return factory


def make_lgb_factory(params, log_fn):
    if not HAS_LGB:
        raise RuntimeError("LightGBM is not installed in this environment.")
    cleaned = clean_params(params, LGB_PARAM_SPECS, none_zero_keys=("subsample_freq",))

    def factory():
        return LGBMRegressor(objective="regression", verbosity=-1, **cleaned)
    return factory


ALGO_FACTORIES = {
    "XGBoost": (make_xgb_factory, True),
    "RandomForest": (make_rf_factory, False),
    "SVR": (make_svr_factory, False),
    "LightGBM": (make_lgb_factory, False),
}

# Algorithms where scaling makes a real accuracy difference and is always
# applied (no opt-out in the GUI); algorithms where it's optional (tree
# models don't strictly need it, but it can still help numerical stability).
MANDATORY_SCALING_ALGOS = ("SVR", "DNN")
OPTIONAL_SCALING_ALGOS = ("XGBoost", "RandomForest", "LightGBM")

SCALER_CHOICES = ["standard", "minmax", "robust", "maxabs"]
SCALER_LABELS = {
    "standard": "StandardScaler (zero mean, unit variance)",
    "minmax": "MinMaxScaler (scales to a 0–1 range)",
    "robust": "RobustScaler (uses median/IQR — resistant to outliers)",
    "maxabs": "MaxAbsScaler (scales by max absolute value, keeps sign/zeros)",
}


def build_scaler(scaler_type):
    """Returns a fresh, unfitted scaler instance for the given choice key."""
    if scaler_type == "minmax":
        return MinMaxScaler()
    elif scaler_type == "robust":
        return RobustScaler()
    elif scaler_type == "maxabs":
        return MaxAbsScaler()
    else:
        return StandardScaler()


def train_sklearn_style_model(algo_name, X_train_raw, y_train, X_test_raw, y_test,
                               params, log_fn=print, stop_flag=None, use_scaling=False,
                               scaler_type="standard"):
    """Trains one of XGBoost / RandomForest / SVR / LightGBM (per-output loop).

    use_scaling=True fits the chosen scaler (see SCALER_CHOICES) on the encoded
    inputs and on the output targets, trains the model in scaled space, and
    stores the scalers in the returned model_data (same mechanism DNN already
    uses). Metrics and plots are always computed in real (unscaled) units
    regardless — scaling only affects what the underlying estimator sees.

    SVR gets scaling forced on regardless of use_scaling — it's not just
    "helpful" for SVR the way it is for tree models, unscaled features can
    make it perform badly, so there's no opt-out for it in the GUI either."""
    if algo_name == "SVR" and not use_scaling:
        log_fn("[INFO] Scaling is mandatory for SVR — enabling it regardless of the setting passed in.")
        use_scaling = True
    input_cols = X_train_raw.columns.tolist()
    encoder, cat_cols = fit_encoder(X_train_raw, log_fn)
    X_train_enc = preprocess_inputs(X_train_raw, encoder, cat_cols, log_fn)
    X_test_enc = preprocess_inputs(X_test_raw, encoder, cat_cols, log_fn)

    defaults, raw_categories = _build_defaults(X_train_raw, input_cols, cat_cols)

    scalers = None
    if use_scaling:
        x_scaler = build_scaler(scaler_type).fit(X_train_enc)
        y_scaler = build_scaler(scaler_type).fit(y_train.values)
        X_train_model = x_scaler.transform(X_train_enc)
        X_test_model = x_scaler.transform(X_test_enc)
        y_train_model = pd.DataFrame(y_scaler.transform(y_train.values),
                                      columns=y_train.columns, index=y_train.index)
        y_test_model = pd.DataFrame(y_scaler.transform(y_test.values),
                                     columns=y_test.columns, index=y_test.index)
        scalers = {"x_scaler": x_scaler, "y_scaler": y_scaler}
        log_fn(f"[INFO] Input/output scaling enabled for this model ({SCALER_LABELS.get(scaler_type, scaler_type)}).")
    else:
        X_train_model, X_test_model = X_train_enc, X_test_enc
        y_train_model, y_test_model = y_train, y_test

    factory_builder, supports_eval_set = ALGO_FACTORIES[algo_name]
    factory = factory_builder(params, log_fn)

    log_fn(f"[STEP] Training {algo_name} ({len(y_train.columns)} outputs)...")
    t0 = time.time()
    models = train_per_output(factory, X_train_model, y_train_model, X_test_model, y_test_model,
                               supports_eval_set, log_fn, stop_flag)
    total_time = time.time() - t0
    if models is None:
        return None

    y_pred_raw = np.column_stack([m.predict(X_test_model) for m in models])
    y_train_pred_raw = np.column_stack([m.predict(X_train_model) for m in models])

    if use_scaling:
        y_pred = scalers["y_scaler"].inverse_transform(y_pred_raw)
        y_train_pred = scalers["y_scaler"].inverse_transform(y_train_pred_raw)
    else:
        y_pred = y_pred_raw
        y_train_pred = y_train_pred_raw

    result = _finalize_result(
        algo_name, models, encoder, cat_cols, input_cols, defaults, raw_categories,
        X_train_raw, X_test_raw, y_train, y_test, y_train_pred, y_pred, total_time, params,
        scalers=scalers,
    )
    result["scaler_type"] = scaler_type if use_scaling else None
    return result


def _build_defaults(X_train_raw, input_cols, cat_cols):
    defaults, raw_categories = {}, {}
    for col in input_cols:
        if col in cat_cols:
            vals = X_train_raw[col].astype(str).str.strip()
            defaults[col] = vals.mode().iloc[0] if not vals.mode().empty else ""
            raw_categories[col] = sorted(vals.unique().tolist())
        else:
            defaults[col] = float(pd.to_numeric(X_train_raw[col], errors="coerce").median())
    return defaults, raw_categories


def _finalize_result(algo_name, models, encoder, cat_cols, input_cols, defaults, raw_categories,
                      X_train_raw, X_test_raw, y_train, y_test, y_train_pred, y_pred,
                      total_time, params, scalers=None):
    n_features = len(input_cols)
    train_metrics = compute_metrics_summary(y_train, y_train_pred, n_features)
    test_metrics = compute_metrics_summary(y_test, y_pred, n_features)

    return {
        "algo": algo_name,
        "models": models,
        "encoder": encoder,
        "cat_cols": cat_cols,
        "input_cols": input_cols,
        "output_cols": y_train.columns.tolist(),
        "defaults": defaults,
        "raw_categories": raw_categories,
        "scalers": scalers,
        "X_train": X_train_raw,
        "y_train": y_train,
        "y_train_pred": y_train_pred,
        "X_test": X_test_raw,
        "y_test": y_test,
        "y_pred": y_pred,
        "train_time_sec": round(total_time, 2),
        "params": params,
        "train_metrics": train_metrics,
        "test_metrics": test_metrics,
        "metadata": {
            "n_input_features": n_features,
            "train_r2_avg": round(float(train_metrics["R2"].mean()), 4),
            "test_r2_avg": round(float(test_metrics["R2"].mean()), 4),
            "train_time_sec": round(total_time, 2),
        },
    }


# ======================================================================
# DNN (TensorFlow / Keras) — single multi-output network
# ======================================================================

def train_dnn_model(X_train_raw, y_train, X_test_raw, y_test, params, log_fn=print, stop_flag=None,
                     scaler_type="standard"):
    if not HAS_TF:
        raise RuntimeError("TensorFlow is not installed in this environment.")

    input_cols = X_train_raw.columns.tolist()
    encoder, cat_cols = fit_encoder(X_train_raw, log_fn)
    X_train_enc = preprocess_inputs(X_train_raw, encoder, cat_cols, log_fn)
    X_test_enc = preprocess_inputs(X_test_raw, encoder, cat_cols, log_fn)
    defaults, raw_categories = _build_defaults(X_train_raw, input_cols, cat_cols)

    # Scaling is mandatory for a DNN (unscaled inputs make training unstable
    # or fail to converge at all) — there's no opt-out, only a choice of which
    # scaler to use.
    x_scaler = build_scaler(scaler_type).fit(X_train_enc)
    y_scaler = build_scaler(scaler_type).fit(y_train.values)
    X_train_s = x_scaler.transform(X_train_enc)
    X_test_s = x_scaler.transform(X_test_enc)
    y_train_s = y_scaler.transform(y_train.values)
    y_test_s = y_scaler.transform(y_test.values)
    log_fn(f"[INFO] Input/output scaling enabled for this model ({SCALER_LABELS.get(scaler_type, scaler_type)}).")

    hidden = [int(h.strip()) for h in str(params.get("hidden_layers", "128,64,32")).split(",") if h.strip()]
    activation = params.get("activation", "relu")
    dropout = float(params.get("dropout_rate", 0.1))
    lr = float(params.get("learning_rate", 0.001))
    opt_name = params.get("optimizer", "adam")
    batch_size = int(params.get("batch_size", 32))
    epochs = int(params.get("epochs", 200))
    patience = int(params.get("early_stopping_patience", 20))
    val_split = float(params.get("validation_split", 0.15))
    loss = params.get("loss", "mse")
    l2_reg = float(params.get("l2_reg", 0.0))

    reg = keras.regularizers.l2(l2_reg) if l2_reg > 0 else None

    model = keras.Sequential(name="dnn_multioutput")
    model.add(keras.Input(shape=(X_train_s.shape[1],)))
    for h in hidden:
        model.add(layers.Dense(h, activation=activation, kernel_regularizer=reg))
        if dropout > 0:
            model.add(layers.Dropout(dropout))
    model.add(layers.Dense(y_train.shape[1], activation="linear"))

    if opt_name == "adam":
        optimizer = keras.optimizers.Adam(learning_rate=lr)
    elif opt_name == "sgd":
        optimizer = keras.optimizers.SGD(learning_rate=lr)
    else:
        optimizer = keras.optimizers.RMSprop(learning_rate=lr)

    loss_fn = "mse" if loss == "mse" else ("mae" if loss == "mae" else keras.losses.Huber())
    model.compile(optimizer=optimizer, loss=loss_fn, metrics=["mae"])

    callbacks = []
    if patience > 0:
        callbacks.append(keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=patience, restore_best_weights=True))

    class _StopFlagCallback(keras.callbacks.Callback):
        def on_epoch_end(self, epoch, logs=None):
            if stop_flag is not None and stop_flag.is_set():
                self.model.stop_training = True

    class _EpochLogCallback(keras.callbacks.Callback):
        """Logs every epoch's loss/val_loss so training progress is visible in
        the GUI log, not just a final summary line."""
        def on_epoch_end(self, epoch, logs=None):
            logs = logs or {}
            parts = [f"  Epoch {epoch + 1}/{epochs}"]
            if "loss" in logs:
                parts.append(f"loss: {logs['loss']:.6f}")
            if "val_loss" in logs:
                parts.append(f"val_loss: {logs['val_loss']:.6f}")
            if "mae" in logs:
                parts.append(f"mae: {logs['mae']:.6f}")
            if "val_mae" in logs:
                parts.append(f"val_mae: {logs['val_mae']:.6f}")
            log_fn(" - ".join(parts))

    callbacks.append(_StopFlagCallback())
    callbacks.append(_EpochLogCallback())

    log_fn(f"[STEP] Training DNN | layers={hidden} activation={activation} epochs={epochs}")
    t0 = time.time()
    history = model.fit(
        X_train_s, y_train_s,
        validation_split=val_split,
        epochs=epochs,
        batch_size=batch_size,
        callbacks=callbacks,
        verbose=0,
    )
    total_time = time.time() - t0
    log_fn(f"[INFO] DNN training finished in {total_time:.2f}s ({len(history.history['loss'])} epochs run)")

    y_pred_s = model.predict(X_test_s, verbose=0)
    y_train_pred_s = model.predict(X_train_s, verbose=0)
    y_pred = y_scaler.inverse_transform(y_pred_s)
    y_train_pred = y_scaler.inverse_transform(y_train_pred_s)

    result = _finalize_result(
        "DNN", model, encoder, cat_cols, input_cols, defaults, raw_categories,
        X_train_raw, X_test_raw, y_train, y_test, y_train_pred, y_pred, total_time, params,
        scalers={"x_scaler": x_scaler, "y_scaler": y_scaler},
    )
    result["scaler_type"] = scaler_type
    result["history"] = history.history
    return result


# ======================================================================
# Save / Load
# ======================================================================

def save_model(model_data, out_dir, base_name):
    os.makedirs(out_dir, exist_ok=True)
    if model_data["algo"] == "DNN":
        keras_path = os.path.join(out_dir, base_name + ".keras")
        scaler_path = os.path.join(out_dir, base_name + "_scalers.pkl")
        model_data["models"].save(keras_path)
        payload = {k: v for k, v in model_data.items() if k not in ("models", "history")}
        joblib.dump(payload, scaler_path)
        return [keras_path, scaler_path]
    else:
        pkl_path = os.path.join(out_dir, base_name + ".pkl")
        joblib.dump(model_data, pkl_path)
        return [pkl_path]


def load_sklearn_style_model(pkl_path):
    return joblib.load(pkl_path)


def load_dnn_model(keras_path, scaler_pkl_path):
    if not HAS_TF:
        raise RuntimeError("TensorFlow is not installed in this environment.")
    model = keras.models.load_model(keras_path)
    payload = joblib.load(scaler_pkl_path)
    payload["models"] = model
    return payload


def save_train_test_results_excel(model_data, out_path):
    """Writes ONE Excel file with train+test prediction results together in a
    single 'Predictions' sheet (marked by a 'Split' column, not separate
    sheets or files), plus a combined 'Metrics_Summary' sheet doing the same
    for the per-coefficient metrics."""
    output_cols = model_data["output_cols"]

    def _build_rows(X_df, y_true_df, y_pred_arr, split_label):
        rows = pd.DataFrame(index=X_df.index)
        rows["Split"] = split_label
        for extra in ("ALPHA", "MACH"):
            if extra in X_df.columns:
                rows[extra] = X_df[extra].values
        for i, col in enumerate(output_cols):
            rows[f"{col}_Actual"] = y_true_df.iloc[:, i].values
            rows[f"{col}_Predicted"] = np.asarray(y_pred_arr)[:, i]
            rows[f"{col}_%Error"] = calculate_percentage_error(y_true_df.iloc[:, i].values, np.asarray(y_pred_arr)[:, i])
        return rows

    train_rows = _build_rows(model_data["X_train"], model_data["y_train"], model_data["y_train_pred"], "Train")
    test_rows = _build_rows(model_data["X_test"], model_data["y_test"], model_data["y_pred"], "Test")
    combined = pd.concat([train_rows, test_rows], ignore_index=True)

    train_m = model_data["train_metrics"].copy()
    train_m.insert(0, "Split", "Train")
    test_m = model_data["test_metrics"].copy()
    test_m.insert(0, "Split", "Test")
    combined_metrics = pd.concat([train_m, test_m], ignore_index=True)

    out_dir = os.path.dirname(out_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        combined.to_excel(writer, sheet_name="Predictions", index=False)
        combined_metrics.to_excel(writer, sheet_name="Metrics_Summary", index=False)
    return out_path


# ======================================================================
# Prediction
# ======================================================================

def _predict_raw(model_data, X_df):
    """Runs the underlying model(s) on already-selected input_cols columns.
    Applies input/output scaling transparently for ANY algo that has scalers
    stored in model_data (not just DNN) — a scaled XGBoost/RandomForest/
    LightGBM model predicts and inverse-transforms exactly the same way."""
    encoder = model_data["encoder"]
    cat_cols = model_data["cat_cols"]
    X_enc = preprocess_inputs(X_df[model_data["input_cols"]], encoder, cat_cols, log_fn=lambda *_: None)

    scalers = model_data.get("scalers")
    X_in = scalers["x_scaler"].transform(X_enc) if scalers is not None else X_enc

    if model_data["algo"] == "DNN":
        pred_raw = model_data["models"].predict(X_in, verbose=0)
    else:
        pred_raw = np.column_stack([m.predict(X_in) for m in model_data["models"]])

    if scalers is not None:
        return scalers["y_scaler"].inverse_transform(pred_raw)
    return pred_raw


def predict_from_dataframe(model_data, df_in, df_out=None):
    """df_in must contain at least model_data['input_cols']. df_out (optional) must
    contain model_data['output_cols'] for actual-vs-predicted comparison."""
    preds = _predict_raw(model_data, df_in)
    output_cols = model_data["output_cols"]

    result_df = pd.DataFrame(index=df_in.index)
    for extra in ("ALPHA", "MACH"):
        if extra in df_in.columns:
            result_df[extra] = df_in[extra].values

    for i, col in enumerate(output_cols):
        if df_out is not None and col in df_out.columns:
            actual = df_out[col].values
        else:
            actual = np.full(len(df_in), np.nan)
        predicted = preds[:, i]
        result_df[f"{col}_Actual"] = actual
        result_df[f"{col}_Predicted"] = predicted
        result_df[f"{col}_%Error"] = calculate_percentage_error(actual, predicted)

    return result_df, preds


def find_nearest_row_indices(df, col, values, cat_cols):
    """For each value, finds the index (in df) of the row whose value in `col`
    is closest (numeric columns) or exactly equal, case-insensitive
    (categorical columns). Returns a list the same length as `values`; an
    entry is None where no match could be found at all (e.g. a categorical
    value that doesn't exist anywhere in df, or the column is entirely blank)."""
    indices = []
    if col in cat_cols:
        col_vals = df[col].astype(str).str.strip().str.lower()
        for v in values:
            target = str(v).strip().lower()
            matches = df.index[col_vals == target]
            indices.append(matches[0] if len(matches) else None)
    else:
        col_vals = pd.to_numeric(df[col], errors="coerce")
        has_valid = col_vals.notna().any()
        for v in values:
            try:
                target = float(v)
            except (TypeError, ValueError):
                indices.append(None)
                continue
            if not has_valid:
                indices.append(None)
                continue
            diffs = (col_vals - target).abs()
            indices.append(diffs.idxmin())
    return indices


def predict_with_override_matched(model_data, df_in, df_out, override_col, override_values):
    """For each override value, finds the nearest REAL row in df_in for the
    given column (exact match for categorical columns, nearest numeric match
    otherwise), overrides just that one column to the exact value requested,
    and predicts — keeping that source row's other inputs and recorded actual
    output as the comparison point. This gives exactly len(override_values)
    prediction points, each with a real (if approximate, for numeric columns)
    'actual' to compare against, so the standard actual-vs-predicted / %error
    / MAAPE / residual plots all work the same way they do for an ordinary
    test-file prediction.

    Returns (result_df, X_used, y_true, preds, unmatched_values) — unmatched
    lists any override values that couldn't be matched to any row at all
    (e.g. a categorical value that doesn't exist anywhere in the test file).
    """
    cat_cols = model_data["cat_cols"]
    output_cols = model_data["output_cols"]
    idxs = find_nearest_row_indices(df_in, override_col, override_values, cat_cols)

    has_actuals_source = df_out is not None and all(c in df_out.columns for c in output_cols)

    rows, y_true_rows, unmatched = [], [], []
    for v, idx in zip(override_values, idxs):
        if idx is None:
            unmatched.append(v)
            continue
        row = df_in.loc[idx, model_data["input_cols"]].to_dict()
        row[override_col] = v
        rows.append(row)
        if has_actuals_source:
            y_true_rows.append(df_out.loc[idx, output_cols].to_dict())
        else:
            y_true_rows.append({c: np.nan for c in output_cols})

    if not rows:
        raise ValueError(f"None of the override values for '{override_col}' matched any row in the test file.")

    X_used = pd.DataFrame(rows)[model_data["input_cols"]]
    y_true = pd.DataFrame(y_true_rows)[output_cols]
    preds = _predict_raw(model_data, X_used)

    result_df = X_used.copy()
    for i, col in enumerate(output_cols):
        result_df[f"{col}_Actual"] = y_true.iloc[:, i].values
        result_df[f"{col}_Predicted"] = preds[:, i]
        result_df[f"{col}_%Error"] = calculate_percentage_error(y_true.iloc[:, i].values, preds[:, i])

    return result_df, X_used, y_true, preds, unmatched


def read_override_values_from_excel(path, sheet_name, column_name):
    """Reads a column of values from an uploaded Excel file to use as the
    override sweep values, as an alternative to typing them in manually."""
    df = pd.read_excel(path, sheet_name=sheet_name)
    if column_name not in df.columns:
        raise ValueError(f"Column '{column_name}' not found in sheet '{sheet_name}'.")
    vals = df[column_name].dropna().tolist()
    if not vals:
        raise ValueError(f"Column '{column_name}' in sheet '{sheet_name}' has no values.")
    return vals


def predict_manual(model_data, feature_values: dict):
    row = {c: feature_values.get(c, model_data["defaults"].get(c, 0)) for c in model_data["input_cols"]}
    df = pd.DataFrame([row])[model_data["input_cols"]]
    preds = _predict_raw(model_data, df)
    return dict(zip(model_data["output_cols"], preds[0]))


# ======================================================================
# Plotting
# ======================================================================

def _grid_shape(n):
    cols = 3 if n >= 3 else n
    rows = math.ceil(n / cols)
    return rows, cols


def plot_actual_vs_predicted(X_ref, y_true_df, y_pred_arr, output_cols, out_path, title, fname_prefix, close_fig=True):
    with MPL_LOCK:
        rows, cols = _grid_shape(len(output_cols))
        fig = Figure(figsize=(6 * cols, 5 * rows))
        axes = fig.subplots(rows, cols)
        axes = np.atleast_1d(axes).flatten()
        fig.suptitle(title, fontsize=16, fontweight="bold")

        use_alpha = "ALPHA" in X_ref.columns
        if use_alpha:
            x_axis = X_ref["ALPHA"].values
            idx = np.argsort(x_axis)
            xlabel = "ALPHA (deg)"
        else:
            x_axis = np.arange(len(y_true_df))
            idx = np.arange(len(y_true_df))
            xlabel = "Sample index"

        for i, col in enumerate(output_cols):
            actual = y_true_df[col].values if hasattr(y_true_df, "columns") else y_true_df[:, i]
            pred = y_pred_arr[:, i]
            actual = np.asarray(actual, dtype=float)
            has_actual = not np.all(np.isnan(actual))
            if has_actual:
                axes[i].plot(x_axis[idx], actual[idx], "o-", label="Actual", alpha=0.6, markersize=4)
            axes[i].plot(x_axis[idx], pred[idx], "s--", label="Predicted", alpha=0.6, markersize=4)
            axes[i].set_title(col, fontweight="bold")
            axes[i].set_xlabel(xlabel)
            axes[i].set_ylabel(col)
            axes[i].grid(True, alpha=0.3)
            axes[i].legend()
        for j in range(len(output_cols), len(axes)):
            axes[j].axis("off")

        fig.tight_layout(rect=[0, 0.03, 1, 0.95])
        fname = os.path.join(out_path, f"{fname_prefix}_ActualVsPredicted.png")
        fig.savefig(fname, dpi=200, bbox_inches="tight")
        if close_fig:
            return fname
        return fname, fig


def plot_percentage_error(X_ref, y_true_df, y_pred_arr, output_cols, out_path, title, fname_prefix, close_fig=True):
    with MPL_LOCK:
        rows, cols = _grid_shape(len(output_cols))
        fig = Figure(figsize=(6 * cols, 5 * rows))
        axes = fig.subplots(rows, cols)
        axes = np.atleast_1d(axes).flatten()
        fig.suptitle(title, fontsize=16, fontweight="bold")

        use_alpha = "ALPHA" in X_ref.columns
        x_axis = X_ref["ALPHA"].values if use_alpha else np.arange(len(y_true_df))
        idx = np.argsort(x_axis) if use_alpha else np.arange(len(y_true_df))
        xlabel = "ALPHA (deg)" if use_alpha else "Sample index"

        for i, col in enumerate(output_cols):
            actual = y_true_df[col].values if hasattr(y_true_df, "columns") else y_true_df[:, i]
            pred = y_pred_arr[:, i]
            pct = calculate_percentage_error(actual, pred)
            abs_pct = np.abs(pct)
            clip_top = min(50, (np.percentile(abs_pct, 98) * 1.2) or 10)
            axes[i].plot(x_axis[idx], abs_pct[idx], "o-", color="darkred", alpha=0.6, markersize=3)
            axes[i].axhline(5.0, color="green", linestyle="--", label="5% target")
            axes[i].axhline(10.0, color="orange", linestyle="--", label="10% tolerance")
            axes[i].set_ylim(0, clip_top if clip_top > 0 else 10)
            axes[i].set_title(f"{col} |%Error|")
            axes[i].set_xlabel(xlabel)
            axes[i].grid(True, alpha=0.3)
            axes[i].legend()
        for j in range(len(output_cols), len(axes)):
            axes[j].axis("off")

        fig.tight_layout(rect=[0, 0.03, 1, 0.95])
        fname = os.path.join(out_path, f"{fname_prefix}_PercentageError.png")
        fig.savefig(fname, dpi=200, bbox_inches="tight")
        if close_fig:
            return fname
        return fname, fig


def plot_maape_error(X_ref, y_true_df, y_pred_arr, output_cols, out_path, title, fname_prefix, close_fig=True):
    with MPL_LOCK:
        rows, cols = _grid_shape(len(output_cols))
        fig = Figure(figsize=(6 * cols, 5 * rows))
        axes = fig.subplots(rows, cols)
        axes = np.atleast_1d(axes).flatten()
        fig.suptitle(title, fontsize=16, fontweight="bold")

        use_alpha = "ALPHA" in X_ref.columns
        x_axis = X_ref["ALPHA"].values if use_alpha else np.arange(len(y_true_df))
        idx = np.argsort(x_axis) if use_alpha else np.arange(len(y_true_df))
        xlabel = "ALPHA (deg)" if use_alpha else "Sample index"

        for i, col in enumerate(output_cols):
            actual = y_true_df[col].values if hasattr(y_true_df, "columns") else y_true_df[:, i]
            pred = y_pred_arr[:, i]
            maape = calculate_maape(actual, pred) / (math.pi / 2) * 100  # as %
            axes[i].plot(x_axis[idx], maape[idx], "o-", color="purple", alpha=0.6, markersize=3)
            axes[i].set_title(f"{col} MAAPE (%)")
            axes[i].set_xlabel(xlabel)
            axes[i].set_ylabel("MAAPE (%)")
            axes[i].grid(True, alpha=0.3)
        for j in range(len(output_cols), len(axes)):
            axes[j].axis("off")

        fig.tight_layout(rect=[0, 0.03, 1, 0.95])
        fname = os.path.join(out_path, f"{fname_prefix}_MAAPE.png")
        fig.savefig(fname, dpi=200, bbox_inches="tight")
        if close_fig:
            return fname
        return fname, fig


def plot_residuals(y_true_df, y_pred_arr, output_cols, out_path, title, fname_prefix, close_fig=True):
    with MPL_LOCK:
        rows, cols = _grid_shape(len(output_cols))
        fig = Figure(figsize=(6 * cols, 5 * rows))
        axes = fig.subplots(rows, cols)
        axes = np.atleast_1d(axes).flatten()
        fig.suptitle(title, fontsize=16, fontweight="bold")

        for i, col in enumerate(output_cols):
            actual = y_true_df[col].values if hasattr(y_true_df, "columns") else y_true_df[:, i]
            pred = y_pred_arr[:, i]
            residual = pred - actual
            axes[i].scatter(pred, residual, alpha=0.5, s=14)
            axes[i].axhline(0, color="black", linestyle="--")
            axes[i].set_title(f"{col} Residuals")
            axes[i].set_xlabel("Predicted")
            axes[i].set_ylabel("Residual (Pred - Actual)")
            axes[i].grid(True, alpha=0.3)
        for j in range(len(output_cols), len(axes)):
            axes[j].axis("off")

        fig.tight_layout(rect=[0, 0.03, 1, 0.95])
        fname = os.path.join(out_path, f"{fname_prefix}_Residuals.png")
        fig.savefig(fname, dpi=200, bbox_inches="tight")
        if close_fig:
            return fname
        return fname, fig


def plot_training_history(history_dict, out_path, title, fname_prefix, close_fig=True):
    with MPL_LOCK:
        fig = Figure(figsize=(8, 5))
        ax = fig.subplots()
        ax.plot(history_dict["loss"], label="Train Loss")
        if "val_loss" in history_dict:
            ax.plot(history_dict["val_loss"], label="Validation Loss")
        ax.set_title(title, fontweight="bold")
        ax.set_xlabel("Epoch")
        ax.set_ylabel("Loss")
        ax.grid(True, alpha=0.3)
        ax.legend()
        fname = os.path.join(out_path, f"{fname_prefix}_TrainingHistory.png")
        fig.savefig(fname, dpi=200, bbox_inches="tight")
        if close_fig:
            return fname
        return fname, fig


def has_valid_actuals(y_true_df, output_cols):
    """True if at least one output column has at least one non-NaN actual value."""
    for col in output_cols:
        vals = y_true_df[col].values if hasattr(y_true_df, "columns") else y_true_df[:, output_cols.index(col)]
        vals = np.asarray(vals, dtype=float)
        if not np.all(np.isnan(vals)):
            return True
    return False


def plot_model_comparison(models_dict, out_dir, title, fname_prefix, metric="R2", close_fig=True):
    """One comparison plot across several trained models: a grouped bar chart
    of a chosen test-set metric (default R2), one group of bars per output
    coefficient common to all the models being compared, one bar per model.

    models_dict: {display_name: model_data}. Raises ValueError if fewer than
    2 models are given, or if they share no output coefficients at all."""
    with MPL_LOCK:
        if len(models_dict) < 2:
            raise ValueError("Need at least 2 trained models to compare.")

        common_cols = None
        for md in models_dict.values():
            cols = set(md["output_cols"])
            common_cols = cols if common_cols is None else (common_cols & cols)
        common_cols = sorted(common_cols) if common_cols else []
        if not common_cols:
            raise ValueError("The selected models don't share any output coefficients, so there's nothing "
                              "comparable between them.")

        model_names = list(models_dict.keys())
        n_models = len(model_names)
        n_cols = len(common_cols)

        os.makedirs(out_dir, exist_ok=True)
        fig = Figure(figsize=(max(8, 2.2 * n_cols), 6))
        ax = fig.subplots()
        bar_width = 0.8 / n_models
        x = np.arange(n_cols)
        cmap = matplotlib.colormaps["tab10"]

        for i, name in enumerate(model_names):
            md = models_dict[name]
            table = md["test_metrics"]
            vals = []
            for col in common_cols:
                row = table[table["coefficient"] == col]
                vals.append(float(row[metric].iloc[0]) if not row.empty and metric in row.columns else np.nan)
            ax.bar(x + i * bar_width, vals, bar_width, label=name, color=cmap(i % 10))

        ax.set_xticks(x + bar_width * (n_models - 1) / 2)
        ax.set_xticklabels(common_cols)
        ax.set_ylabel(f"Test {metric}")
        ax.set_title(title, fontsize=16, fontweight="bold")
        ax.legend()
        ax.grid(True, alpha=0.3, axis="y")
        if metric == "R2":
            ax.axhline(1.0, color="gray", linestyle="--", linewidth=0.8)

        fig.tight_layout()
        fname = os.path.join(out_dir, f"{fname_prefix}_ModelComparison.png")
        fig.savefig(fname, dpi=200, bbox_inches="tight")
        if close_fig:
            return fname
        return fname, fig



def generate_all_plots(model_data, out_dir, title_prefix, fname_prefix,
                        X_override=None, y_true_override=None, y_pred_override=None,
                        include_error_plots=None, return_regenerators=False):
    """Generates the standard plot suite from a trained model_data dict.

    By default uses model_data['X_test'] / ['y_test'] / ['y_pred'] (post-training
    validation plots). Pass X_override/y_true_override/y_pred_override to plot a
    different dataset (e.g. a prediction run on a new test file) using the same
    trained model's output_cols.

    If include_error_plots is None, it's auto-detected: error/MAAPE/residual plots
    are only produced when real actual values are present (they're meaningless
    against NaN ground truth). actual_vs_predicted is always produced.

    If return_regenerators=True, also returns a dict of {plot_key: zero-arg
    callable} that redraws that same plot fresh as a live matplotlib Figure —
    used to embed interactive (pan/zoom) plots in the GUI instead of a static
    image, without duplicating the plotting logic at the call site.
    """
    os.makedirs(out_dir, exist_ok=True)
    output_cols = model_data["output_cols"]
    X_ref = X_override if X_override is not None else model_data["X_test"]
    y_true = y_true_override if y_true_override is not None else model_data["y_test"]
    y_pred = y_pred_override if y_pred_override is not None else model_data["y_pred"]

    if include_error_plots is None:
        include_error_plots = has_valid_actuals(y_true, output_cols)

    paths = {}
    regens = {}

    paths["actual_vs_predicted"] = plot_actual_vs_predicted(
        X_ref, y_true, y_pred, output_cols, out_dir, f"{title_prefix} — Actual vs Predicted", fname_prefix)
    regens["actual_vs_predicted"] = lambda: plot_actual_vs_predicted(
        X_ref, y_true, y_pred, output_cols, out_dir, f"{title_prefix} — Actual vs Predicted", fname_prefix,
        close_fig=False)[1]

    if include_error_plots:
        paths["percentage_error"] = plot_percentage_error(
            X_ref, y_true, y_pred, output_cols, out_dir, f"{title_prefix} — % Error", fname_prefix)
        regens["percentage_error"] = lambda: plot_percentage_error(
            X_ref, y_true, y_pred, output_cols, out_dir, f"{title_prefix} — % Error", fname_prefix,
            close_fig=False)[1]

        paths["maape"] = plot_maape_error(
            X_ref, y_true, y_pred, output_cols, out_dir, f"{title_prefix} — MAAPE", fname_prefix)
        regens["maape"] = lambda: plot_maape_error(
            X_ref, y_true, y_pred, output_cols, out_dir, f"{title_prefix} — MAAPE", fname_prefix,
            close_fig=False)[1]

        paths["residuals"] = plot_residuals(
            y_true, y_pred, output_cols, out_dir, f"{title_prefix} — Residuals", fname_prefix)
        regens["residuals"] = lambda: plot_residuals(
            y_true, y_pred, output_cols, out_dir, f"{title_prefix} — Residuals", fname_prefix, close_fig=False)[1]

    if model_data["algo"] == "DNN" and "history" in model_data:
        history = model_data["history"]
        paths["training_history"] = plot_training_history(
            history, out_dir, f"{title_prefix} — Training History", fname_prefix)
        regens["training_history"] = lambda: plot_training_history(
            history, out_dir, f"{title_prefix} — Training History", fname_prefix, close_fig=False)[1]

    if return_regenerators:
        return paths, regens
    return paths
